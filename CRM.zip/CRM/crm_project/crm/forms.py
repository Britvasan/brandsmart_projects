from django import forms
from .models import NewCustomer

class NewCustomerForm(forms.ModelForm):
    class Meta:
        model = NewCustomer
        fields = ['customer_name', 'company', 'phone_number', 'email', 'platform']
