from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from .models import NewCustomer, ScheduledActivity
from .forms import NewCustomerForm
from django.views.decorators.csrf import csrf_exempt


def crm_dashboard(request):
    customers = NewCustomer.objects.all()
    activities = ScheduledActivity.objects.all()
    form = NewCustomerForm()
    
    if request.method == "POST":
        form = NewCustomerForm(request.POST)
        if form.is_valid():
            customer = form.save()
            return JsonResponse({
                'id': customer.id,
                'customer_name': customer.customer_name,
                'company': customer.company,
                'phone_number': customer.phone_number,
                'email': customer.email,
                'platform': customer.get_platform_display(),
                'status': customer.status,
            })
    new_customers = NewCustomer.objects.filter(status='new').order_by('-id')  # ✅ Newest first
    followup1_customers = NewCustomer.objects.filter(status='followup1').order_by('-id')
    followup2_customers = NewCustomer.objects.filter(status='followup2').order_by('-id')
    followup3_customers = NewCustomer.objects.filter(status='followup3').order_by('-id')
    not_interested_customers = NewCustomer.objects.filter(status='not_interested').order_by('-id')

    return render(request, "crm/dashboard.html", {
        "customers": customers,
        "activities":activities, 
        "form": form,
        "new_customers": new_customers,
        "followup1_customers": followup1_customers,
        "followup2_customers": followup2_customers,
        "followup3_customers": followup3_customers,
        "not_interested_customers": not_interested_customers
    })

@csrf_exempt
def update_customer_status(request, customer_id):
    if request.method == "POST":
        try:
            customer = NewCustomer.objects.get(id=customer_id)
            new_status = request.POST.get("status")

            # ✅ Validate the status before updating
            allowed_statuses = ["new", "followup1", "followup2", "followup3", "not_interested"]
            if new_status not in allowed_statuses:
                return JsonResponse({"error": "Invalid status"}, status=400)

            customer.status = new_status
            customer.save()

            return JsonResponse({"success": True, "status": new_status})

        except NewCustomer.DoesNotExist:
            return JsonResponse({"error": "Customer not found"}, status=404)

    return JsonResponse({"error": "Invalid request"}, status=400)
        

def get_customer(request, customer_id):
    try:
        customer = NewCustomer.objects.get(id=customer_id)
        data = {
            "id": customer.id,
            "customer_name": customer.customer_name,
            "company": customer.company,
            "phone_number": customer.phone_number,
            "email": customer.email,
            "platform": customer.platform,
            "status": customer.status,
        }
        return JsonResponse(data)
    except NewCustomer.DoesNotExist:
        return JsonResponse({"error": "Customer not found"}, status=404)

@csrf_exempt
def update_customer(request, customer_id):
    if request.method == "POST":
        customer = get_object_or_404(NewCustomer, id=customer_id)
        customer.customer_name = request.POST.get("customer_name")
        customer.company = request.POST.get("company")
        customer.phone_number = request.POST.get("phone_number")
        customer.email = request.POST.get("email")
        customer.platform = request.POST.get("platform")
        customer.save()

        return JsonResponse({
            "id": customer.id,
            "customer_name": customer.customer_name,
            "company": customer.company,
            "phone_number": customer.phone_number,
            "email": customer.email,
            "platform": customer.platform,
            "status": customer.status,
        })

@csrf_exempt
def delete_customer(request, customer_id):
    if request.method == "POST":
        try:
            customer = NewCustomer.objects.get(id=customer_id)
            customer.delete()
            return JsonResponse({"success": True})
        except NewCustomer.DoesNotExist:
            return JsonResponse({"success": False, "error": "Customer not found"}, status=404)

@csrf_exempt
def schedule_activity(request):
    if request.method == "POST":
        customer_id = request.POST.get("customer_id")
        activity_type = request.POST.get("activity_type")
        due_date = request.POST.get("due_date")
        summary = request.POST.get("summary")

        customer = NewCustomer.objects.get(id=customer_id)

        activity = ScheduledActivity.objects.create(
            customer_id=customer_id,
            customer = customer,
            activity_type=activity_type,
            due_date=due_date,
            summary=summary
        )

        return JsonResponse({
            "success": True,
            "customer_id": customer_id,
            "activity_type": activity.activity_type
        })

    return JsonResponse({"success": False}, status=400)