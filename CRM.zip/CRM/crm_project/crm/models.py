from django.db import models

class NewCustomer(models.Model):
    PLATFORM_CHOICES = [
        ('paperdesk', 'PaperDesk'),
        ('print3', 'Print3'),
        ('texmart', 'Texmart'),
        ('polymart', 'Polymart'),
        ('corrugman', 'Corrugman'),
        ('freshnfrozen', 'Freshnfrozen'),
       
    ]
    STATUS_CHOICES = [
        ('new', 'New'),
        ('followup1', 'Follow-up 1'),
        ('followup2', 'Follow-up 2'),
        ('followup3', 'Follow-up 3'),
        ('not_interested', 'Not Interested')
    ]
    
    customer_name = models.CharField(max_length=255)
    company = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=20)
    email = models.EmailField()
    platform = models.CharField(max_length=50, choices=PLATFORM_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new')

    def __str__(self):
        return self.customer_name
    

class ScheduledActivity(models.Model):
    ACTIVITY_CHOICES = [
        ("Meeting", "Meeting"),
        ("Call", "Call"),
        ("Email", "Email"),
        ("WhatsApp", "WhatsApp"),
        ("Others", "Others"),
    ]
    
    customer = models.ForeignKey("NewCustomer", on_delete=models.CASCADE)
    activity_type = models.CharField(max_length=20, choices=ACTIVITY_CHOICES)
    due_date = models.DateField()
    summary = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.customer} - {self.activity_type}"
