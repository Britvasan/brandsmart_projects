$(document).ready(function () {

    // Show/Hide New Customer Form
    $("#addNewCustomerBtn").click(function () {
        $("#newCustomerFormContainer").slideToggle();
        $("#newCustomerForm")[0].reset();
        $("#newCustomerForm").removeAttr("data-id");  // Remove existing customer ID (important)
    });

    // ✅ Handle form submission via AJAX for adding/updating a customer
    $("#newCustomerForm").submit(function (event) {
        event.preventDefault();

        var customerId = $(this).attr("data-id");
        var ajaxUrl = customerId ? `/update_customer/${customerId}/` : "{% url 'crm:crm_dashboard' %}";
        var successMessage = customerId ? "Customer updated successfully!" : "Customer added successfully!";

        $.ajax({
            type: "POST",
            url: ajaxUrl,
            data: $(this).serialize(),
            success: function (response) {
                console.log(response);

                if (response.id && response.status) {
                    let newCard = $(`
                    <div class="customer-card platform-${response.platform}" data-id="${response.id}">
                        <div class="card-header d-flex justify-content-between">
                            <h5>${response.customer_name}</h5>
                            <i class="fa-solid fa-ellipsis-vertical options-icon"></i>
                            <div class="options-menu d-none">
                                <button class="edit-customer btn btn-sm btn-primary" data-id="${response.id}"><i class="fa-solid fa-pen"></i></button>
                                <button class="delete-customer btn btn-sm btn-danger" data-id="${response.id}"><i class="fa-solid fa-trash"></i></button>
                            </div>
                        </div>
                        <p><strong>Company:</strong> ${response.company}</p>
                        <p><strong>Phone:</strong> ${response.phone_number}</p>
                        <p><strong>Email:</strong> ${response.email}</p>
                        <p><strong>Platform:</strong> ${response.platform}</p>
                    </div>`);

                    // ✅ Append the new card to the correct status section

                    console.log("Appending new card to status:", response.status);
                    $("#" + response.status).prepend(newCard);

                    // ✅ Hide form and reset it
                    $("#newCustomerFormContainer").slideUp();
                    $("#newCustomerForm")[0].reset();

                    // ✅ Ensure FontAwesome icons re-render
                    if (window.FontAwesome) {
                        window.FontAwesome.dom.i2svg();
                    } else {
                        console.error("Failed to add new customer. Response is missing id or status:", response);
                    }
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX Error:", error);
            }
        });
    });

    // trigger options menu to dropdown edit and delete button
    $(document).on("click", ".options-icon", function (event) {
        event.stopPropagation(); // Prevent closing when clicking inside

        var dropdown = $(this).siblings(".options-menu");
        $(".options-menu").not(dropdown).addClass("d-none"); // Close other dropdowns
        dropdown.toggleClass("d-none"); // Toggle current dropdown
    });

    // Close the dropdown when clicking outside
    $(document).click(function () {
        $(".options-menu").addClass("d-none");
    });


    // ✅ Edit Customer
    // ✅ Edit Customer - Fetch Data and Populate Form
    $(document).on("click", ".edit-customer", function () {
        var customerId = $(this).data("id");

        $.ajax({
            type: "GET",
            url: `/get_customer/${customerId}/`,  // Django View to fetch customer details
            success: function (data) {
                // Populate the form with existing customer data
                $("input[name='customer_name']").val(data.customer_name);
                $("input[name='company']").val(data.company);
                $("input[name='phone_number']").val(data.phone_number);
                $("input[name='email']").val(data.email);
                $("select[name='platform']").val(data.platform);

                // Store the customer ID in the form (important for update request)
                $("#newCustomerForm").attr("data-id", customerId);

                // Show the form for editing
                $("#newCustomerFormContainer").slideDown();
            }
        });
    });

    // ✅ Delete Customer
    $(document).on("click", ".delete-customer", function () {
        var customerId = $(this).data("id");

        if (!confirm("Are you sure you want to delete this customer?")) return;

        $.ajax({
            type: "POST",
            url: `/delete_customer/${customerId}/`,
            headers: { "X-CSRFToken": "{{ csrf_token }}" },
            success: function (response) {
                if (response.success) {
                    $(`.customer-card[data-id='${customerId}']`).remove();
                } else {
                    alert("Failed to delete customer!");
                }
            }
        });
    });

    // ✅ Drag and Drop for status change
    $(".kanban-section").sortable({
        connectWith: ".kanban-section",
        placeholder: "sortable-placeholder",
        items: ".customer-card",
        update: function (event, ui) {
            var customer_id = ui.item.attr("data-id");
            var new_status = ui.item.closest(".kanban-section").attr("id");

            if (!customer_id || !new_status) {
                console.error("Error: Missing customer_id or new_status!");
                return;
            }

            // ✅ Validate status before sending request
            let allowedStatuses = ["new", "followup1", "followup2", "followup3", "not_interested"];
            if (!allowedStatuses.includes(new_status)) {
                console.error("Invalid status:", new_status);
                return;
            }

            $.ajax({
                url: `/update_customer_status/${customer_id}/`,
                method: "POST",
                headers: { "X-CSRFToken": "{{ csrf_token }}" },
                data: { status: new_status },
                success: function (response) {
                    if (response.success) {
                        console.log(`Customer ${customer_id} status updated to ${new_status}`);
                    } else {
                        console.error("Failed to update status:", response.error);
                    }
                },
                error: function (xhr, status, error) {
                    console.error("AJAX Error:", error);
                }
            });
        }
    }).disableSelection();

    // ✅ Ensure all customer cards have the ellipsis icon
    $(".customer-card").each(function () {
        let header = $(this).find(".card-header");

        if (header.find(".options-icon").length === 0) {
            header.append('<i class="fa-solid fa-ellipsis-vertical options-icon"></i>');
        }
    });
});
