from django.urls import path
from . import views

app_name = 'crm'

urlpatterns = [
    path("", views.crm_dashboard, name="crm_dashboard"),
    path("update_customer_status/<int:customer_id>/", views.update_customer_status, name="update_customer_status"),
    path('get_customer/<int:customer_id>/', views.get_customer, name='get_customer_details'),
    path('update_customer/<int:customer_id>/', views.update_customer, name='update_customer'),
    path('delete_customer/<int:customer_id>/', views.delete_customer, name='delete_customer'),
    path('schedule_activity/', views.schedule_activity, name='schedule_activity')
]